if (typeof(comigsformswidgets) == 'undefined') comigsformswidgets = new Object();
if (typeof(comigsformswidgets.library) == 'undefined') comigsformswidgets.library = new Object();
if (typeof(comigsformswidgets.library.NavigationWidgetWrapper) == 'undefined') {

	comigsformswidgets.library.NavigationWidgetWrapper = function(){};
    console.log("start igs forms - navigation widget");
    
    var wrapper = comigsformswidgets.library.NavigationWidgetWrapper;

    wrapper.MARKUP = "" + 
        "<div>" +        	
        	"<div id='naviheader'>" +
      			"<div id='navi'></div>" +      			
      		"</div>" +    			
        "</div>";

    wrapper.prototype.initialize = function(component, renderMode) {
    	console.log("initialize navigation widget");        
    	
        this.component = component;
    	this.renderMode = renderMode;
    	this.rendered = false;
    	
    	// The logger available here has the same API as the logger available within Form action scripts. 
        this.logger = this.component.getLogger();
        if (this.logger.isDebugEnabled()) this.logger.debug("NavigationWidgetWrapper.initialize(). renderMode: " + renderMode);
        
    	var parent = this.component.getParentNode();	
    	$(parent).html(comigsformswidgets.library.NavigationWidgetWrapper.MARKUP);
    	
    	this.rendered = true;
    };
        
    wrapper.prototype.refresh = function(updates) {  
    	console.log("refresh navigation widget ...");
    	var self = this;  
    	
    	var actions = self.component.getControl().form.getParameterValue("action");
    	
    	var html = "";
    	actions.forEach(createActions);
  	  	
	  	function createActions(item, index) {
			html = html + "<h3><label>"+item+"</label></h3><br>";
		}    	  	            
        
	  	console.log("navigation widget - dynamic html source: " + html);
        $('#navi').html("<h1>Navigation</h1><br>"+ html);

        $('#naviheader label').click(function() {
            //alert('You clicked a label named ' + $(this).html() +'!');
            self.component.getControl().form.setParameterValue("actionToDo", $(this).html());    		  
    		self.component.getControl().form.invokeAction('submit', self, self.component);
        });           
    };
    
    wrapper.prototype.destroy = function() {    	
    };
    
}
